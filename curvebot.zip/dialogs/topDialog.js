// async nameStep(stepContext) {
//     // Create an object in which to collect the user's information within the dialog.
//     stepContext.values.userInfo = new UserProfile();

//     const promptOptions = { prompt: 'Please enter your name.' };

//     // Ask the user to enter their name.
//     return await stepContext.prompt(TEXT_PROMPT, promptOptions);
// };

// async ageStep(stepContext) {
//     // Set the user's name to what they entered in response to the name prompt.
//     stepContext.values.userInfo.name = stepContext.result;

//     const promptOptions = { prompt: 'Please enter your age.' };

//     // Ask the user to enter their age.
//     return await stepContext.prompt(NUMBER_PROMPT, promptOptions);
// }

// async startSelectionStep(stepContext) {
//     // Set the user's age to what they entered in response to the age prompt.
//     stepContext.values.userInfo.age = stepContext.result;

//     if (stepContext.result < 25) {
//         // If they are too young, skip the review selection dialog, and pass an empty list to the next step.
//         await stepContext.context.sendActivity('You must be 25 or older to participate.');

//         return await stepContext.next();
//     } else {
//         // Otherwise, start the review selection dialog.
//         return await stepContext.beginDialog(REVIEW_SELECTION_DIALOG);
//     }
// }

// async acknowledgementStep(stepContext) {
//     // Set the user's company selection to what they entered in the review-selection dialog.
//     const userProfile = stepContext.values.userInfo;
//     userProfile.companiesToReview = stepContext.result || [];

//     await stepContext.context.sendActivity(`Thanks for participating ${ userProfile.name }`);

//     // Exit the dialog, returning the collected user information.
//     return await stepContext.endDialog(userProfile);
// }v